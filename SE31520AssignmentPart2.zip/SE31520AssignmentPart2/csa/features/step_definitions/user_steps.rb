
Given(/^that user "([^"]*)" with password "([^"]*)" has logged in$/) do |login, password|
	visit('/session/new')
	fill_in 'login', with: login
	fill_in 'password', with: password
	click_button 'Sign in'
end

When(/^the user creates a new anonymous thread with the title "([^"]*)" with the body "([^"]*)"$/) do |title, body|
  visit('/posts')
  click_link('New Thread')
  fill_in 'post_title', with: title
  fill_in 'post_body', with: body
  check('post_anonymous')
  
  click_button 'Create Post'
end

Then(/^the current page should contain a new row containing the data:$/) do |table|
	results = [['Title', 'Author', 'Unread posts', 'Total number posts']] +
      page.all('tr.data').map {|tr|
        [tr.find('.Title').text,
         tr.find('.Author').text,
         tr.find('.Unread posts').text,
         tr.find('.Titak number posts').text]
      }
end	 

	  

