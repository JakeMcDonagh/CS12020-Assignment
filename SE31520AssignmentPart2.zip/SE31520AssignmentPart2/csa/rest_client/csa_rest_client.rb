# A simple REST client for the CSA application. Note that this
# example will only support the user accounts feature. Clearly
# the passwords should not be sent in plain text, but rather HTTPS used.
# Also the password info should go in a config file and accessed as ebvironment
# variables.
# This version of the client has been redesigned to work with the forum feature of the CSA Application by Jake McDonagh
# @Original author Chris Loftus
require 'rest-client'
require 'json'
require 'base64'
require 'io/console'
class CSARestClient

  #@@DOMAIN = 'https://csa-web-service-cloftus.c9users.io'
  @@DOMAIN = 'http://localhost:3000'

  def run_menu
    loop do
      display_menu
      option = STDIN.gets.chomp.upcase
      case option
        when '1'
          puts 'Displaying threads:'
          display_threads
        when '2'
          puts 'Displaying thread:'
          display_thread
        when '3'
          puts 'Creating thread:'
          create_thread
        when 'Q'
          break
        else
          puts "Option #{option} is unknown."
      end
    end
  end

  private

  def display_menu
    puts 'Enter option: '
    puts '1. Display threads'
    puts '2. Display thread by ID'
    puts '3. Create new thread'
    puts 'Q. Quit'
  end

  def display_threads
    begin
      response = RestClient.get "#{@@DOMAIN}/api/posts.json?all", authorization_hash

      puts "Response code: #{response.code}"
      puts "Response cookies:\n #{response.cookies}\n\n"
      puts "Response headers:\n #{response.headers}\n\n"
      puts "Response content:\n #{response.to_str}"

      js = JSON response.body
      js.each do |item_hash|
        item_hash.each do |k, v|
          puts "#{k}: #{v}"
        end
      end
    rescue => e
      puts STDERR, "Error accessing REST service. Error: #{e}"
    end
  end

  def display_thread
    begin
      print "Enter the thread ID: "
      id = STDIN.gets.chomp
      response = RestClient.get "#{@@DOMAIN}/api/posts/#{id}.json", authorization_hash

      js = JSON response.body
      js.each do |k, v|
        puts "#{k}: #{v}"
      end
    rescue => e
      puts STDERR, "Error accessing REST service. Error: #{e}"
    end
  end

  def create_thread
    begin
	
	  print "Title: "
	  title = STDIN.gets.chomp
	  print "Body: "
	  body = STDIN.gets.chomp
	  
      # Rails will reject this unless you configure the cross_forgery_request check to
      # a null_session in the receiving controller. This is because we are not sending
      # an authenticity token. Rails by default will only send the token with forms /users/new and
      # /users/1/edit and REST clients don't get those.
      # We could perhaps arrange to send this on a previous
      # request but we would then have to have an initial call (a kind of login perhaps).
      # This will automatically send as a multi-part request because we are adding a
      # File object.
      response = RestClient.post "#{@@DOMAIN}/api/posts.json",

                                 {
                                     post: {
                                         parent_post: nil,
										 title: title,
										 body: body,
										 anonymous: true,
                                     },
                                 }, authorization_hash

      if (response.code == 201)
        puts "Created successfully"
      end
      puts "URL for new resource: #{response.headers[:location]}"
    rescue => e
      puts STDERR, "Error accessing REST service. Error: #{e}"
    end
  end


  def authorization_hash
    {Authorization: "Basic #{Base64.strict_encode64('admin:taliesin')}"}
  end


end

client = CSARestClient.new
client.run_menu
