class RemoveColumnFromPost < ActiveRecord::Migration[5.1]
  def change
    remove_column :posts, :child_posts, :integer
  end
end
