class RemoveLoginFromPosts < ActiveRecord::Migration[5.1]
  def change
    remove_column :posts, :login, :string
  end
end
