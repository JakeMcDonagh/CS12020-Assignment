I18n.default_locale = 'en'

LOCALES_DIRECTORY = "#{Rails.root.to_s}/config/locales/"

LANGUAGES = {
  'English' => 'en',
  'Cymraeg' => 'cw'
}
