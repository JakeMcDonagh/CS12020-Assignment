#The properties that are within the post section of the database.
#@Author Jake McDonagh
class Post < ApplicationRecord
	validates_presence_of :title
	validates_presence_of :body
	belongs_to :user
	has_many :children, dependent: :destroy, class_name: 'Post', foreign_key: :parent_post
	
end
