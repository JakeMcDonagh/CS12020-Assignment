# Handles incoming user account HTTP requests for the posts
class API::PostsController < API::ApplicationController

  before_action :set_post, only: [:show, :update, :destroy]
  before_action :admin_required, only: [:index, :destroy]
  

  # GET /posts.json
  def index
	@posts = Post.where(parent_post: nil).paginate(page: params[:page],
                           per_page: params[:per_page])
                 .order('parent_post', 'created_at').reverse_order 
				 	 
  end

  # GET /posts/1.json
  def show
  end

  # POST /posts.json
  def create
    @post = Post.new(post_params)

    respond_to do |format|
      if @post.save
        format.json { render :show, status: :created, location: @post }
      else
        format.json { render json: @post.errors, status: :unprocessable_entity }
      end
    end
  end


  # PATCH/PUT /posts/1.json
  def update
    respond_to do |format|
      if @post.update(post_params)
        format.json { render :show, status: :ok, location: @post }
      else
        format.json { render json: @post.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /posts/1.json
  def destroy
    @post.destroy
    respond_to do |format|
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_post
      @post = Post.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def post_params
      params.require(:post).permit(:parent_post, :user_id, :anonymous, :title, :body, :child_posts)
    end
end
